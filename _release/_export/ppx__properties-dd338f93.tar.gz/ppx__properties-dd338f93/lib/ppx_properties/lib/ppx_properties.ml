(** @canonical Ppx_properties.Lenses *)
module Lenses = Ppx_properties__Lenses

(** @canonical Ppx_properties.Lenses_Gen *)
module Lenses_Gen = Ppx_properties__Lenses_Gen
