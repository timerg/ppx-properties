# ppx-properties

Auto derive get/set/update methods for reasonml's record.

